<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="vertical"
    android:background="@color/sand" android:fitsSystemWindows="true">
    <ScrollView android:id="@+id/page_scroll" android:layout_width="match_parent" android:layout_height="0dp" android:layout_weight="1" android:fillViewport="true">
        <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="vertical" android:paddingStart="18dp" android:paddingEnd="18dp" android:paddingTop="12dp" android:paddingBottom="16dp">
            <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="horizontal" android:gravity="center_vertical">
                <Button android:id="@+id/menu_button" android:layout_width="48dp" android:layout_height="48dp" android:minWidth="48dp" android:padding="0dp" android:background="@android:color/transparent" android:text="≡" android:textSize="25sp" android:textColor="#303538" android:contentDescription="Abrir configurações"/>
                <TextView android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:gravity="center" android:text="VEGAS" android:textColor="#303538" android:textSize="34sp" android:textStyle="bold"/>
                <TextView android:layout_width="48dp" android:layout_height="48dp" android:gravity="center" android:text="✈︎" android:textColor="#008B89" android:textSize="30sp" android:importantForAccessibility="no"/>
            </LinearLayout>
            <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:gravity="center" android:text="veloz e segura" android:textSize="18sp" android:textColor="#202A2D"/>
            <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:gravity="center" android:layout_marginTop="4dp" android:text="Vegas • alimentação VPN Gate" android:textSize="12sp" android:textColor="#40575A"/>

            <LinearLayout android:id="@+id/home_page" android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="vertical">
                <Button android:id="@+id/connect_button" android:layout_width="220dp" android:layout_height="220dp" android:layout_gravity="center" android:layout_marginTop="18dp" android:background="@drawable/status_ring" android:text="⏻\VIAJAR" android:textAllCaps="false" android:textColor="#075F67" android:textSize="22sp" android:textStyle="bold"/>
                <TextView android:id="@+id/vpn_status" android:layout_width="match_parent" android:layout_height="wrap_content" android:gravity="center" android:layout_marginTop="8dp" android:accessibilityLiveRegion="polite" android:textColor="#303538" android:textSize="14sp"/>
                <LinearLayout android:id="@+id/server_card" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="16dp" android:orientation="horizontal" android:gravity="center_vertical" android:background="@drawable/card" android:padding="16dp" android:minHeight="72dp" android:clickable="true" android:focusable="true" android:contentDescription="Buscar servidores">
                    <TextView android:layout_width="48dp" android:layout_height="wrap_content" android:text="모" android:textColor="#007D80" android:textSize="30sp" android:importantForAccessibility="no"/>
                    <LinearLayout android:layout_width="0dp" android:layout_height="wrap_content" android:layout_weight="1" android:orientation="vertical">
                        <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:text="Servidores" android:textColor="#303538" android:textSize="16sp"/>
                        <TextView android:id="@+id/selected_server" android:layout_width="match_parent" android:layout_height="wrap_content" android:text="Selecionar servidor" android:textColor="#303538" android:textSize="18sp"" android:textStyle="bold"/>
                    </LinearLayout>
                    <TextView android:layout_width="wrap_content" android:layout_height="wrap_content" android:text="›" android:textSize="32sp" android:textColor="#D96454" android:importantForAccessibility="no"/>
                </LinearLayout>
                <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="12dp" android:orientation="horizontal" android:gravity="center_vertical" android:background="@drawable/card" android:padding="16dp">
                    <TextView android:layout_width="48dp" android:layout_height="wrap_content" android:text="ᯓ" android:textColor="#007D80" android:textSize="30sp" android:importantForAccessibility="no"/>
                    <TextView android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:text="Uso de dados\nWi-Fi: indisponível\nDados móveis: indisponíveis" android:textColor="#303538" android:textSize="15sp"/>
                </LinearLayout>
                <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="18dp" android:text="Servidores recentes" android:textColor="#303538" android:textSize="18sp" android:textStyle="bold"/>
                <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="8dp" android:background="@drawable/card" android:padding="16dp" android:text="Nenhum histórico salvo" android:textColor="#596266" android:textSize="14sp"/>
            </LinearLayout>

            <LinearLayout android:id="@+id/servers_page" android:layout_width="match_parent" android:layout_height="wrap_content" android:visibility="gone" android:orientation="vertical" android:layout_marginTop="20dp">
                <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:text="Servidores" android:textColor="#303538" android:textSize="24sp" android:textStyle="bold"/>
                <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="8dp" android:text="@string/servers_description" android:textColor="#40575A" android:textSize="14sp"/>
                <Button android:id="@+id/refresh_catalog" style="@style/VegasPrimaryButton" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="14dp" android:text="@string/catalog_refresh"/>
                <TextView android:id="@+id/catalog_status" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="12dp" android:accessibilityLiveRegion="polite" android:text="@string/catalog_initial" android:textColor="#40575A" android:textSize="14sp"/>
                <LinearLayout android:id="@+id/server_list" android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="vertical"/>
            </LinearLayout>
            <LinearLayout android:id="@+id/settings_page" android:layout_width="match_parent" android:layout_height="wrap_content" android:visibility="gone" android:orientation="vertical" android:layout_marginTop="20dp">
                <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:text="Configurações" android:textColor="#303538" android:textSize="24sp" android:textStyle="bold"/>
                <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="12dp" android:background="@drawable/card" android:padding="16dp" android:text="VPN do Android\nConsulte as conexões e opções VPN nas configurações do aparelho." android:textColor="#303538" android:textSize="15sp"/>
                <Button android:id="@+id/system_vpn" style="@style/VegasPrimaryButton" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="8dp" android:text="Abrir configurações VPN"/>
                <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="16dp" android:background="@drawable/card" android:padding="16dp" android:text="Widget Vegas ✈︎\nAdicione o widget pela tela inicial do Android. A configuração de detalhes aparece ao adicioná-lo. Ele mostra apenas o estado do catálogo." android:textColor="#303538" android:textSize="15sp"/>
                <TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_marginTop="16dp" android:text="Os servidores são operados por voluntários Vegas -  VPN Gate" android:textColor="#40575A" android:textSize="14sp"/>
            </LinearLayout>
        </LinearLayout>
    </ScrollView>
    <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="horizontal" android:background="#FFFCF7" android:paddingTop="4dp" android:paddingBottom="4dp">
        <Button android:id="@+id/nav_home" android:layout_width="0dp" android:layout_weight="1" android:layout_height="64dp" android:background="@android:color/transparent" android:text="⌂\nInício" android:textAllCaps="false" android:textSize="14sp" android:textColor="#007D80"/>
        <Button android:id="@+id/nav_servers" android:layout_width="0dp" android:layout_weight="1" android:layout_height="64dp" android:background="@android:color/transparent" android:text="모\nServidores" android:textAllCaps="false" android:textSize="14sp" android:textColor="#303538"/>
        <Button android:id="@+id/nav_settings" android:layout_width="0dp" android:layout_weight="1" android:layout_height="64dp" android:background="@android:color/transparent" android:text="⏣\nConfigurações" android:textAllCaps="false" android:textSize="14sp" android:textColor="#303538"/>
    </LinearLayout>
</LinearLayout>
