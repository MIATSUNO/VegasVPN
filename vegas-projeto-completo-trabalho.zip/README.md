# Vegas — VPN Gate + estudo Tor experimental, sem conexão

**Estado desta cópia combinada:** Modo Tor é distinto do catálogo VPN Gate, não se conecta e não bloqueia tráfego. `tests/TorSafetyModel.java` é somente modelo offline simulado, fora do app; não é motor ou proteção. Veja `INTEGRACAO-VPNGATE-TOR-20261116.md` e os relatórios históricos. Não existe motor VPN (OpenVPN, WireGuard ou outro) nem motor Tor.

**Base VPN Gate:** o catálogo agora aplica a triagem restritiva a cada perfil recebido e mostra o resultado, mas a conexão permanece permanentemente bloqueada. Não foram integrados motor OpenVPN, `VpnService`, TLS de túnel ou Tor. Veja `OPENVPN-RESULTADO-20261116.md` para testes, build, licença pesquisada, limitações e próximos passos. Qualquer APK debug gerado é **somente catálogo**, não oferece proteção. O texto a seguir é documentação herdada; onde disser que a triagem não é utilizada, prevalece esta nota.

Esta cópia reúne o widget com estados de catálogo e inspeção superficial de perfis, além de uma pesquisa Arti isolada em `tests/`. **Não há VPN, Tor, túnel, kill switch ou proteção contra vazamentos; Conectar e Tor continuam desativados.** A internet normal continua funcionando. Esta variante não foi publicada nem validada em dispositivo. O projeto mantém INTERNET para a consulta manual ao catálogo, não para uma conexão VPN/Tor.

## Privacidade e inspeção

A consulta é manual e exige confirmação a cada tentativa; comunica-se por HTTPS com o VPN Gate, serviço externo que recebe IP e horário. Seu uso definitivo precisa de aprovação, pois diverge do pedido anterior sem APIs. Segundo a [política antiabuso](https://www.vpngate.net/en/about_abuse.aspx), acessos à lista são registrados e logs de conexões VPN são retidos por três meses ou mais, com IP de origem e metadados de destinos; servidores voluntários retêm cabeçalhos de pacotes por pelo menos duas semanas. Isso descreve a política do terceiro, não uma conexão VPN neste app. Sem promessa de anonimato ou ausência de logs.

Perfis até 100 registros são decodificados exclusivamente em memória, limitados a 192 KiB de Base64, sem exibição, armazenamento ou execução. O CSV e dados sensíveis podem permanecer temporariamente na memória sem apagamento garantido. Indicamos apenas presença superficial de `remote-cert-tls server`, `verify-x509-name` ou `peer-fingerprint`, ignorando comentários e blocos inline: não é parser OpenVPN completo nem verificação de autenticidade, parâmetros ou segurança. Encontrar uma diretiva não prova segurança; não a encontrar não prova falha. HTTPS do diretório não autentica cada servidor voluntário. Não habilite conexões com base nesse diagnóstico.

A pesquisa Arti e SOCKS usa testes locais isolados, fora de `app/src`; **não integra Arti ou Tor**. Leia `ARTI-RESULTADO-E-PROXIMOS-PASSOS.md`; não aponte o experimento a uma porta real: uma porta local não autentica seu dono. Os testes usam apenas proxy falso no loopback; não validam Tor, TLS, Android ou vazamentos.

## Testes e CI

Com Python 3 e JDK 17: `python3 tests/verify_project.py`, `python3 tests/verify_isolation.py`, `python3 tests/run_java_tests.py`. O CI executa esses testes Java efetivos antes de tentar o Gradle, mas o workflow não foi executado nesta cópia. Sem wrapper; build requer JDK 17, Gradle 8.10.2, SDK Android 35 e build-tools 34.0.0. Testes estáticos e compilação direta não substituem Gradle, APK executável ou validação em dispositivos. Ícone tem direitos de distribuição não confirmados.

## Detalhes herdados da variante widget

**Esta é uma cópia separada de `vegas-catalogo-vpngate`. Não foi publicada. Não é uma VPN e não oferece proteção.** O widget mostra sempre “VPN indisponível” e acompanha apenas o estado real da consulta ao catálogo de terceiros. Não há indicador de conexão ativa, tráfego, bytes, proteção ou promessa de funcionamento VPN.

## Widget e estados nesta variante

Adicione o widget pela tela inicial do Android; a configuração de cada instância permite mostrar ou ocultar a dica de abertura. Ao tocar, abre o app; não dispara uma consulta. Para consultar o catálogo é necessário tocar no botão e confirmar a divulgação ao VPN Gate. Os resultados continuam apenas em memória; após a morte do processo o estado da última consulta pode permanecer, mas a lista não é apresentada como atual. As preferências são privadas e `allowBackup=false`. O widget atualiza todas as instâncias após as transições, quando o launcher solicita atualização e ao redimensionar; não há polling. O launcher pode mostrar uma visualização inicial antes de o provedor atualizar. Preferências de widget são eliminadas ao remover a instância. A reconfiguração posterior depende de suporte e não foi habilitada: remova e adicione novamente.

Estados do **catálogo**, não de VPN: IDLE (nunca consultado), LOADING (consulta em andamento), SUCCEEDED (consulta concluída, inclusive com zero registros válidos), FAILED (erro) e INTERRUPTED (processo anterior morreu durante consulta). Somente IDLE/SUCCEEDED/FAILED/INTERRUPTED → LOADING e LOADING → SUCCEEDED/FAILED/INTERRUPTED são aceitas; valor desconhecido retorna IDLE. Ao iniciar um novo processo com LOADING, o repositório marca INTERRUPTED. A atualização é em processo único: não use multiprocess ou adicione serviço sem rever concorrência e recuperação. `SharedPreferences.commit()` é síncrono; falha de disco não bloqueia a consulta, mas o último estado pode não sobreviver ao encerramento. O trabalho pertence ao processo, não é serviço de longa duração: a consulta pode ser interrompida pelo Android. Recriação da Activity não inicia outra consulta e não descarta resultados ainda em memória.

## Limitações e próximos passos

O applicationId é igual ao da base; instalação com assinatura compatível pode substituir outra variante. Para coexistência, altere o applicationId e teste a configuração do widget. Não houve testes em launcher, acessibilidade, rotação, processo morto, restauração, aparelho ou emulador nesta consolidação. Testar duas instâncias, cancelamento, redimensionamento, remoção, reinício, falha de rede e consentimento.

Uma VPN real exige decisão de fonte, licenças e identidade dos servidores, motor auditável, serviço VPN com consentimento, rotas IPv4/IPv6 e DNS, proteção do socket, prevenção de vazamentos e testes independentes. Arti requer resolver bootstrap, identidade do SOCKS, proveniência, licenças, compatibilidade e segurança antes de cogitar integração; não basta porta aberta ou start(). O ícone tem titularidade não confirmada.
